N = int(input())

A = list(map(int,input().split()))

A.sort()

a = N // 2

print(A[a])